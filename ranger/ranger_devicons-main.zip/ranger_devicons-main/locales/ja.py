translations = {
    'デスクトップ': 'Desktop',
    'ドキュメント': 'Documents',
    'ダウンロード': 'Downloads',
    '音楽': 'Music',
    '画像': 'Pictures',
    '公開': 'Public',
    'テンプレート': 'Templates',
    'ビデオ': 'Videos',
}
