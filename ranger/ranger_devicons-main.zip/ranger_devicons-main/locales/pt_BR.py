translations = {
    'Área de Trabalho': 'Desktop',
    'Documentos': 'Documents',
    'Downloads': 'Downloads',
    'Música': 'Music',
    'Imagens': 'Pictures',
    'Público': 'Public',
    'Modelos': 'Templates',
    'Vídeos': 'Videos',
}
