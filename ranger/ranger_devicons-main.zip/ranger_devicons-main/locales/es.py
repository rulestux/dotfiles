translations = {
    'Escritorio': 'Desktop',
    'Documentos': 'Documents',
    'Descargas': 'Downloads',
    'Música': 'Music',
    'Imágenes': 'Pictures',
    'Público': 'Public',
    'Plantillas': 'Templates',
    'Vídeos': 'Videos',
}
