translations = {
    'Рабочий стол': 'Desktop',
    'Документы': 'Documents',
    'Загрузки': 'Downloads',
    'Музыка': 'Music',
    'Изображения': 'Pictures',
    'Общедоступные': 'Public',
    'Шаблоны': 'Templates',
    'Видео': 'Videos',
}
