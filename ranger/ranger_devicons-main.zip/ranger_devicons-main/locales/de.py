translations = {
    'Schreibtisch': 'Desktop',
    'Dokumente': 'Documents',
    'Downloads': 'Downloads',
    'Musik': 'Music',
    'Bilder': 'Pictures',
    'Öffentlich': 'Public',
    'Vorlagen': 'Templates',
    'Videos': 'Videos',
}
