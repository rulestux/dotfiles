translations = {
    'Bureau': 'Desktop',
    'Documents': 'Documents',
    'Images': 'Pictures',
    'Musique': 'Music',
    'Publique': 'Public',
    'Téléchargements': 'Downloads',
    'Modèles': 'Templates',
    'Vidéos': 'Videos',
}
