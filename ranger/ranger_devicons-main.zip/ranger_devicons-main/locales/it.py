translations = {
    'Scrivania': 'Desktop',
    'Documenti': 'Documents',
    'Scaricati': 'Downloads',
    'Musica': 'Music',
    'Immagini': 'Pictures',
    'Pubblici': 'Public',
    'Modelli': 'Templates',
    'Video': 'Videos',
}
