translations = {
    '桌面': 'Desktop',
    '文档': 'Documents',
    '下载': 'Downloads',
    '音乐': 'Music',
    '图片': 'Pictures',
    '公共': 'Public',
    '模板': 'Templates',
    '视频': 'Videos',
}
